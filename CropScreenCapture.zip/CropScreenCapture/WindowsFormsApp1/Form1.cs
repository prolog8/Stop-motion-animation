﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Drawing.Imaging;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Clipboard.ContainsImage())
            {
                Image img = Clipboard.GetImage();

                Rectangle src_rect = new Rectangle(
                    Convert.ToInt32(txtX.Text),
                    Convert.ToInt32(txtY.Text),
                    Convert.ToInt32(txtW.Text),
                    Convert.ToInt32(txtH.Text));

                Rectangle dest_rect = new Rectangle(
                    0, 0,
                    Convert.ToInt32(txtW.Text),
                    Convert.ToInt32(txtH.Text));

                Bitmap bm = new Bitmap(dest_rect.Width, dest_rect.Height);
                Graphics g = Graphics.FromImage(bm);

                g.DrawImage(img, 
                    dest_rect, 
                    src_rect, 
                    GraphicsUnit.Pixel);



                // Export filename
                string filename_temp = txtPath.Text.Trim();
                //string path = txtPath.Text.Trim();
                //if (!path.EndsWith("\\")) { path += "\\"; }

                

                for (int i=1;;i++)
                {
                    //string filename = path + "A" + i.ToString("000") + ".png";

                    string filename = string.Format(filename_temp, i.ToString("000"));

                    if (!File.Exists(filename))
                    {
                        Clipboard.SetImage(bm);
                        Clipboard.GetImage().Save(filename, ImageFormat.Png);

                        return;
                    }

                }
                
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Bitmap bm = new Bitmap(
                    Convert.ToInt32(txtW.Text),
                    Convert.ToInt32(txtH.Text));

            Graphics g = Graphics.FromImage(bm);
            g.CopyFromScreen(
                  new Point(Convert.ToInt32(txtX.Text), Convert.ToInt32(txtY.Text)),
                  new Point(0, 0),
                  new Size(Convert.ToInt32(txtW.Text), Convert.ToInt32(txtH.Text)));

            // Export filename
            string filename_temp = txtPath.Text.Trim();

            for (int i = 1; ; i++)
            {
                string filename = string.Format(filename_temp, i.ToString("000"));

                if (!File.Exists(filename))
                {
                    Clipboard.SetImage(bm);
                    Clipboard.GetImage().Save(filename, ImageFormat.Png);
                    return;
                }
            }

        }
    }
}
